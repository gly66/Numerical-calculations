import numpy as np
import math
from scipy.optimize import fsolve

# fx零点在（0，1）
def f(x):
    return math.pow(x, 2) - 3*x + 2 - math.pow(math.e, x)
def f_d(x):
    return 2*x - 3 - math.pow(math.e, x)
# fx的迭代格式为f_w，此格式收敛
def f_w(x):
    return (x**2 + 2 - math.e**x)/3
# gx零点在（1.3，1.4）
def g(x):
    return math.pow(x, 3) + 2*math.pow(x, 2) + 10*x - 20
def g_d(x):
    return 3*math.pow(x, 2) + 4*x + 10
# gx的迭代格式为g_w，此格式收敛
def g_w(x):
    return 20/(x**2 + 2*x + 10)
# 精度
s = 10e-8
# 迭代步数
step_f_fixed = 0
step_g_fixed = 0
step_f_sp = 0
step_g_sp = 0
step_f_nt = 0
step_g_nt = 0

# 计算结果
x_f_fixed = 0.0
x_g_fixed = 0.0
x_f_sp = 0.0
x_g_sp = 0.0
x_f_nt = 0.0
x_g_nt = 0.0


# fx不动点迭代
def fixed_f():
    x_0 = 0.0
    x_1 = 0.0
    for k in range(1,100):
        x_1 = f_w(x_0)
        if abs(x_1 - x_0) < s:
            return k,x_1
        else:
            x_0 = x_1


# gx不动点迭代
def fixed_g():
    x_0 = 1.3
    x_1 = 0.0
    for k in range(1,100):
        x_1 = g_w(x_0)
        if abs(x_1 - x_0) < s:
            return k,x_1
        else:
            x_0 = x_1



# fx斯蒂芬森加速
def sp_f():
    x_0 = 0.0
    x_1 = 0.0
    for k in range(1,100):
        y = f_w(x_0)
        z = f_w(y)
        x_1 = x_0 - ((y-x_0)**2)/(z-2*y+x_0)
        if abs(x_1 - x_0) < s:
            return k,x_1
        else:
            x_0 = x_1


# gx斯蒂芬森加速
def sp_g():
    x_0 = 1.3
    x_1 = 0.0
    for k in range(1,100):
        y = g_w(x_0)
        z = g_w(y)
        x_1 = x_0 - ((y-x_0)**2)/(z-2*y+x_0)
        if abs(x_1 - x_0) < s:
            return k,x_1
        else:
            x_0 = x_1



# fx牛顿法
def nt_f():
    x_0 = 0.0
    x_1 = 0.0
    for k in range(1,100):
        x_1 = x_0 - f(x_0)/f_d(x_0)
        print(x_1)
        if abs(x_1 - x_0) < s:
            return k,x_1
        else:
            x_0 = x_1


# gx牛顿法
def nt_g():
    x_0 = 1.3
    x_1 = 0.0
    for k in range(1,100):
        x_1 = x_0 - g(x_0)/g_d(x_0)
        print(x_1)
        if abs(x_1 - x_0) < s:
            return k,x_1
        else:
            x_0 = x_1


# fx结果
print("fx结果：迭代初值设为0.0")
step_f_fixed, x_f_fixed = fixed_f()
print("fx不动点迭代，迭代步数和迭代结果为",step_f_fixed,"  ",x_f_fixed)
step_f_sp, x_f_sp = sp_f()
print("fx斯蒂芬森加速迭代，迭代步数和迭代结果为",step_f_sp,"  ",x_f_sp)
step_f_nt, x_f_nt = nt_f()
print("fx牛顿迭代，迭代步数和迭代结果为",step_f_nt,"  ",x_f_nt)
print("\n")

#gx结果
print("gx结果：迭代初值设为1.3")
step_g_fixed, x_g_fixed = fixed_g()
print("gx不动点迭代，迭代步数和迭代结果为",step_g_fixed,"  ",x_g_fixed)
step_g_sp, x_g_sp = sp_g()
print("gx斯蒂芬森加速迭代，迭代步数和迭代结果为",step_g_sp,"  ",x_g_sp)
step_g_nt, x_g_nt = nt_g()
print("gx牛顿迭代，迭代步数和迭代结果为",step_g_nt,"  ",x_g_nt)