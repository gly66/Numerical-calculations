import numpy as np
import math
from numpy.linalg import  inv

def fx1(x1,x2,x3):
    return 3*x1 - np.cos(x2*x3) - 1/2
def fx2(x1,x2,x3):
    return math.pow(x1,2) - 81*math.pow(x2+0.1,2) + np.sin(x3) + 1.06
def fx3(x1,x2,x3):
    return math.pow(math.e,(-x1*x2)) + 20*x3 + 10*math.pi/3 - 1

def f_w1(x1,x2,x3):
    return (np.cos(x2*x3) + 0.5)/3
def f_w2(x1,x2,x3):
    return ((x1**2 + np.sin(x3) + 1.06)**0.5)/9 - 0.1
def f_w3(x1,x2,x3):
    return -(math.e**(-x1*x2) + 10*math.pi/3 - 1)/20
s = 10e-8

# 不动点迭代
x_0 = np.array([0.0,0,0])
x_1 = np.array([0.0,0,0])
print("不动点迭代,迭代初值为 ",x_0)
for i in range(1,100):
    x_1[0] = f_w1(x_0[0],x_0[1],x_0[2])
    x_1[1] = f_w2(x_0[0],x_0[1],x_0[2])
    x_1[2] = f_w3(x_0[0],x_0[1],x_0[2])
    print("第"+str(i)+"次迭代： ",x_1)
    S = abs(max(x_1-x_0, key=abs))
    if S < s:
        print("满足精度，迭代结果： ",x_1)
        break
    else:
        x_0 = x_1.copy()

print("\n")
# 牛顿法
x_0 = np.array([0.0,0,0])
x_1 = np.array([0.0,0,0])
print("牛顿法,迭代初值为 ",x_0)
for i in range(1,100):
    F = np.array([-fx1(x_0[0],x_0[1],x_0[2]), -fx2(x_0[0],x_0[1],x_0[2]), -fx3(x_0[0],x_0[1],x_0[2])]).reshape(-1,1)

    F_d = np.array([[3, (-x_0[2]*np.sin(x_0[1]*x_0[2])), (-x_0[1]*np.sin(x_0[1]*x_0[2]))],
                   [2*x_0[0], -162*(x_0[1]+0.1), np.cos(x_0[2])],
                   [-x_0[1]*math.pow(math.e, x_0[0]*x_0[1]), -x_0[0]*math.pow(math.e, x_0[0]*x_0[1]), 20]]).reshape(3,3)
    dx = np.dot(inv(F_d),F).reshape(1,-1)
    d = np.squeeze(dx,axis=0)
    x_1 = x_0 + d
    print("第"+str(i)+"次迭代： ",x_1)
    S = abs(max(d, key=abs))
    if S < s:
        print("满足精度，迭代结果： ",x_1)
        break
    else:
        x_0 = x_1.copy()
