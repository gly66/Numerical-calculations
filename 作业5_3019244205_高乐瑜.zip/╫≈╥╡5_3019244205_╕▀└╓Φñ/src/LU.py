import numpy as np

key = int(input("输入1用测试用例， 输入其他数将随机生成A，b:  "))

n = 0
if key == 1:
    n = 9
    A = [[30.0, 33, -43, -11, -38, -29, 37, 28, 23],
         [-480, -523, 644, 128, 621, 480, -618, -489, -329],
         [60, 266, -1862, -1991, 464, 546, -968, -1567, 1652],
         [540, 624, -782, 290, -893, 123, 567, 5, -122],
         [-450, -675, 2245, 2326, -1512, 1230, -822, 129, -189],
         [-300, -120, -1114, -1295, 1946, 302, -376, -1540, -609],
         [1080, 998, 508, 2460, -1628, -1358, 2896, 2828, -2002],
         [-1080, -1408, 3340, 2267, 21, -1202, 866, -2690, -1351],
         [-300, -435, 1594, 1685, 340, 2279, -27, 2917, -2336]]
    A = np.array(A)
    b = [188.0, -3145, -4994, 680, 7845, 1876, 9712, -11599, 10127]
    b = np.array(b)
else:
    n = int(input("输入n(>=20)的值，将随机生成n阶矩阵A和n维向量b: "))
    A = np.random.randint(-50, 50, (n, n))
    b = np.random.randint(-50, 50, n)

print("选取的A和b为： ")
print(A)
print(b)

# LU分解得L和U矩阵
L = np.zeros((n, n))
U = np.zeros((n, n))
for j in range(n):
    U[0][j] = A[0][j]
for i in range(n):
    L[i][i] = 1
for i in range(1, n):
    L[i][0] = A[i][0]/U[0][0]


for i in range(1, n):
    # 对U矩阵来说，i是行，u是列
    for u in range(i, n):
        U[i][u] = A[i][u]
        for k in range(0, i):
            U[i][u] -= L[i][k]*U[k][u]
    # 对L矩阵来说，i是列，l是行
    if i != n-1:
        for l in range(i+1, n):
            L[l][i] = A[l][i]
            for k in range(0, i):
                L[l][i] -= L[l][k]*U[k][i]
            L[l][i] = L[l][i]/U[i][i]

print("分解后得到的的L：")
print(L)
print("分解后得到的U：")
print(U)


y = []
y.append(b[0])
for i in range(1, n):
    temp = b[i]
    for k in range(0, i):
        temp -= L[i][k]*y[k]
    y.append(temp)
# 回代求解，从n-1到0
x = []
for i in range(n):
    index = n - i - 1
    temp = y[index]
    for j in range(0, i):
        col_index = n - j - 1
        temp -= x[j] * U[index][col_index]
    temp = temp/U[index][index]
    x.append(temp)
x = list(reversed(x))

print("解得方程根值x*为： ")
print(x)