import numpy as np

key = int(input("输入1用测试用例， 输入其他数将随机生成A，b:  "))

n = 0
if key == 1:
    n = 9
    A = [[31.0, -13, 0, 0, 0, -10, 0, 0, 0],
         [-13, 35, -9, 0, -11, 0, 0, 0, 0],
         [0, -9, 31, -10, 0, 0, 0, 0, 0],
         [0, 0, -10, 79, -30, 0, 0, 0, -9],
         [0, 0, 0, -30, 57, -7, 0, -5, 0],
         [0, 0, 0, 0, -7, 47, -30, 0, 0],
         [0, 0, 0, 0, 0, -30, 41, 0, 0],
         [0, 0, 0, 0, -5, 0, 0, 27, -2],
         [0, 0, 0, -9, 0, 0, 0, -2, 29]]
    A = np.array(A)
    b = [-15.0, 27, -23, 0, -20, 12, -7, 7, 10]
    b = np.array(b)
else:
    n = int(input("输入n(>=20)的值，将随机生成n阶矩阵A和n维向量b: "))
    A = np.random.randint(-50, 50, (n, n))
    b = np.random.randint(-50, 50, n)

print("选取的A和b为： ")
print(A)
print(b)


# 同时交换A 和 b的对应行
def swap_row(A, b, i, j):
    temp1 = []
    for q in range(n):
        temp1.append(A[i][q])
    A[i] = A[j]
    A[j] = temp1
    temp2 = b[i]
    b[i] = b[j]
    b[j] = temp2


# 列主元法
for k in range(n-1):
    max_value = A[k][k]
    max_index = k
    for u in range(k+1, n):
        if A[u][k] > max_value:
            max_value = A[u][k]
            max_index = u
    if max_index != k:
        swap_row(A, b, k, max_index)
    for i in range(k+1, n):
        m = A[i, k]/A[k, k]
        for j in range(k, n):
            A[i][j] = A[i][j] - A[k][j] * m
        b[i] = b[i] - b[k] * m

print("输出： ")
print("消元后的增广矩阵(分A，b输出)： ")
print("A:\n", A)
print("b: ", b)

# 回代求解，从n-1到0
x = []
for i in range(n):
    index = n - i - 1
    temp = b[index]
    for j in range(0, i):
        col_index = n - j - 1
        temp -= x[j] * A[index][col_index]
    temp = temp/A[index][index]
    x.append(temp)
x = list(reversed(x))

print("解得方程根值x*为： ")
print(x)

