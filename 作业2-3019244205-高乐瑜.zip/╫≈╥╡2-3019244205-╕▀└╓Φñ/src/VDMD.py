import numpy as np
import matplotlib.pyplot as plt
from numpy.linalg import inv

n = int(input("n的值： "))
m = int(input("m的值: "))
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))
d = int(input("d: "))
e = int(input("e: "))
f = int(input("f: "))
# a = 0 b = 10 n = 9  m = 20
# c = 1 d = 2 e = 3 f = 4

# 计算范德蒙行列式
def Vandermonder(x):
    temp = []
    for i in x:
        for j in range(n+1):
            temp.append(np.power(i, j))
    return temp


# 多项式计算
def Pn(x):
    pn = 0.0
    i = 0
    for j in range(n+1):
        pn += a1[i] * np.power(x, j)
        i += 1
    return pn


# 插值节点,默认生成a到b的包含n+1个数的等差数列
x = np.linspace(a, b, n+1)
# 插值节点函数值
y = c*np.sin(d*x) + e*np.cos(f*x)

# AX=B 解方程得a
B = y
A = np.array(Vandermonder(x)).reshape(n+1, n+1)
X = np.dot(inv(A), B)
a1 = X

# VDMD 估算m个点的值
x1 = np.linspace(a, b, m)
y1 = []
for k in x1:
    y1.append(Pn(k))


# VDMD平均误差
y_n = c*np.sin(d*x1) + e*np.cos(f*x1)
y_error_v = y1 - y_n
y_error_a_v = np.mean(y_error_v)
print("VDMD average error: ", y_error_a_v)

# 画图
l1, = plt.plot(x, y, label='theory')
l2, = plt.plot(x1, y1, label='VDMD', linestyle='--')
plt.scatter(x1, y1)
plt.xlabel("x")
plt.ylabel("y")
plt.title('VDMD')
plt.savefig("VDMD.png")
plt.legend()   # 打上标签
plt.show()
