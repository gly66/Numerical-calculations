import numpy as np
import matplotlib.pyplot as plt

n = int(input("n的值： "))
m = int(input("m的值: "))
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))
d = int(input("d: "))
e = int(input("e: "))
f = int(input("f: "))
# a = 0 b = 10 n = 9  m = 20
# c = 1 d = 2 e = 3 f = 4




# lagrange
# 计算连乘
def T(x, i, X):
    T_i = 1
    for x_i in X:
        if X[i] == x_i:
            continue
        T_i = T_i * (x - x_i)
    return T_i


# 插值基函数
def P(i, x, X):
    P_i = T(x, i, X) / T(X[i], i, X)
    return P_i


# 计算预测值
def L(x, X, Y):
    result = 0
    for i in range(n+1):
        result = result + P(i, x, X) * Y[i]
    return result




# 插值节点,默认生成a到b的包含n+1个数的等差数列
X = np.linspace(a, b, n+1)
# 插值节点函数值
Y = c*np.sin(d*X) + e*np.cos(f*X)

# lagrange 估算m个点的值
x = np.linspace(a, b, m)
y = L(x, X, Y)
# lagrange平均误差
y_n = c*np.sin(d*x) + e*np.cos(f*x)
y_error_lg = y - y_n
y_error_a_lg = np.mean(y_error_lg)
print("lagrange average error: ", y_error_a_lg)


# 画图
l1, = plt.plot(X, Y, label='theory')
l2, = plt.plot(x, y, label='lagrange', linestyle='--')
# l3, = plt.plot(x_v, y_v, label='VDMD', linestyle='--')
plt.xlabel("x")
plt.ylabel("y")
plt.scatter(x, y)
plt.title('lagrange')
plt.savefig("lagrange.png")
plt.legend()   # 打上标签
plt.show()

