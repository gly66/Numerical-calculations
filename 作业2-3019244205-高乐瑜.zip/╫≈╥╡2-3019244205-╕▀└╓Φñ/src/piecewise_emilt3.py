import numpy as np
import matplotlib.pyplot as plt

n = int(input("n的值： "))
m = int(input("m的值: "))
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))
d = int(input("d: "))
e = int(input("e: "))
f = int(input("f: "))
# a = 0 b = 10 n = 9  m = 20
# c = 1 d = 2 e = 3 f = 4

# 判断估算值x在哪个小区间
def judge(x):
    index = []
    for i in range(m):
        for j in range(1, n+1):
            if x[i] <= X[j]:
                tmp = j-1
                index.append(tmp)
                break
    return index


def emilt3(x, X, Y, Y_d):
    index = judge(x)
    result = []
    for i in range(m):
        id = index[i]
        tmp = 0
        tmp += np.power(((x[i]-X[id+1])/(X[id]-X[id+1])), 2) * (1 + 2*(x[i]-X[id])/(X[id+1]-X[id])) * Y[id]
        tmp += np.power(((x[i]-X[id])/(X[id+1]-X[id])), 2) * (1 + 2*(x[i]-X[id+1])/(X[id]-X[id+1])) * Y[id+1]
        tmp += np.power(((x[i]-X[id+1])/(X[id]-X[id+1])), 2) * (x[i]-X[id]) * Y_d[id]
        tmp += np.power(((x[i]-X[id])/(X[id+1]-X[id])), 2) * (x[i]-X[id+1]) * Y_d[id+1]
        result.append(tmp)
    return result


# 插值节点,默认生成a到b的包含n+1个数的等差数列
X = np.linspace(a, b, n+1)
# 插值节点函数值
Y = c*np.sin(d*X) + e*np.cos(f*X)
# 插值节点导数值
Y_d = c*d*np.cos(d*X) - e*f*np.sin(f*X)

# linear 估算m个点的值
x = np.linspace(a, b, m)
y = emilt3(x, X, Y, Y_d)

# linear平均误差
y_n = c*np.sin(d*x) + e*np.cos(f*x)
y_error_l = y - y_n
y_error_a_l = np.mean(y_error_l)
print("emilt3 average error: ", y_error_a_l)

# 画图
l1, = plt.plot(X, Y, label='theory')
l2, = plt.plot(x, y, label='emilt3', linestyle='--')
plt.scatter(x, y)
plt.xlabel("x")
plt.ylabel("y")
plt.title('emilt3')
plt.savefig("emilt3.png")
plt.legend()   # 打上标签
plt.show()

