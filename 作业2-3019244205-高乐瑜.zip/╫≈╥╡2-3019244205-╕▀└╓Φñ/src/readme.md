***

## 作业说明
本次编程作业共实现五种插值法

**VDMD.py** 实现范德蒙德插值

**lagrange.py** 实现拉格朗日插值

**newton.py** 实现牛顿插值

**piecewise_emilt3** 实现分段三次埃米尔特插值

**piecewise_linear** 实现分段线性插值

