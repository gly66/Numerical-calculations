import numpy as np
import matplotlib.pyplot as plt

n = int(input("n的值： "))
m = int(input("m的值: "))
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))
d = int(input("d: "))
e = int(input("e: "))
f = int(input("f: "))
# a = 0 b = 10 n = 9  m = 20
# c = 1 d = 2 e = 3 f = 4

'''
计算差商表
def get_diff_table(X, Y):
    A = np.zeros([n+1, n+1])

    for i in range(0, n+1):
        A[i][0] = Y[i]

    for j in range(1, n+1):
        for i in range(j, n+1):
            A[i][j] = (A[i][j - 1] - A[i - 1][j - 1]) / (X[i] - X[i - j])

    return A
'''

# 计算牛顿插值估值
def newton_interpolation(X, Y, x):
    sum = Y[0]
    temp = np.zeros((n+1, n+1))
    # 将第一列赋值
    for i in range(0, n+1):
        temp[i, 0] = Y[i]
    temp_sum = 1.0
    for i in range(1, n+1):
        # x的多项式
        temp_sum = temp_sum*(x-X[i-1])
        # 计算均差
        for j in range(i, n+1):
            temp[j, i] = (temp[j, i-1]-temp[j-1, i-1])/(X[j]-X[j-i])
        sum += temp_sum*temp[i, i]
    return sum


# 插值节点,默认生成a到b的包含n+1个数的等差数列
X = np.linspace(a, b, n+1)
# 插值节点函数值
Y = c*np.sin(d*X) + e*np.cos(f*X)

# newton 估算m个点的值
x = np.linspace(a, b, m)
y = newton_interpolation(X,Y,x)

# newton平均误差
y_n = c*np.sin(d*x) + e*np.cos(f*x)
y_error_nt = y - y_n
y_error_a_nt = np.mean(y_error_nt)
print("newton average error: ", y_error_a_nt)

# 画图
l1, = plt.plot(X, Y, label='theory')
l2, = plt.plot(x, y, label='newton', linestyle='--')
plt.scatter(x, y)
plt.xlabel("x")
plt.ylabel("y")
plt.title('newton')
plt.savefig("newton.png")
plt.legend()   # 打上标签
plt.show()

