import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt

n = int(input("n的值： "))
m = int(input("m的值: "))
k = int(input("k的值: "))
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))

# a = 0 b = 10 n = 9  m = 20  k = 1，2，3
# c = 2


# 递推形式的 legendre多项式
def P(n, x):
    if n == 0:
        return 1
    elif n == 1:
        return x
    else:
        return ((2*n-1)/float(n)) * x * P(n-1,x) - ((n-1)/float(n)) * P(n-2,x)


# 区间变换，x(实际为t)定义域为-1 到 1
def f(x):
    return (1 / (1 + c * ((a + b)/2 + ((b-a)/2)*x) * ((a + b)/2 + ((b-a)/2)*x)))


res = []
# 求参数a， 右侧矩阵由于legendre，只有对角线元素，为2/(2n+1)，因此每个方程只有一项，直接除2/(2n+1)即可。
for i in range(k+1):
    p = integrate.quad(lambda x: f(x)*P(i, x), -1, 1)
    p1 = p[0]
    tmp = p[0]/(2/(2*i+1))
    res.append(tmp)

res1 = list(reversed(np.array(res)))


# 插值节点,默认生成a到b的包含n+1个数的等差数列
X = np.linspace(a, b, n)
# 插值节点函数值
Y = 1/(1 + c * np.power(X, 2))

# 生成多项式函数(此时自变量为t)
F = np.poly1d(res1)
print(F)

x = np.linspace(a, b, m)
# t为x对应的[-1,1]上的值
t = (x - (a+b)/2)*(2/(b-a))
print(t)
y_r = 1/(1 + c * np.power(x, 2))
y = []
for i in range(m):
    y.append(F(t[i]))


y_e = y - y_r
y_error_a = np.mean(y_e)
print("average error: ", y_error_a)

# 画图
l1, = plt.plot(X, Y, label='theory')
l2, = plt.plot(x, y, label='least_square', linestyle='--')
plt.scatter(x, y)
plt.xlabel("x")
plt.ylabel("y")
plt.title('legendre')
plt.savefig("legendre.png")
plt.legend()   # 打上标签
plt.show()
