***

## 作业说明
本次编程作业共实现两种函数逼近

**legendre.py** 实现最佳平方逼近

**least_square.py** 实现最小二乘法

