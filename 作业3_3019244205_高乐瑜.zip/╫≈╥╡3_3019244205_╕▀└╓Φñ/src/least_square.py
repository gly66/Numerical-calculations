import numpy as np
import matplotlib.pyplot as plt

n = int(input("n的值： "))
m = int(input("m的值: "))
k = int(input("k的值: "))
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))

# a = 0 b = 10 n = 9  m = 20  k = 1，2，3
# c = 2


# 插值节点,默认生成a到b的包含n+1个数的等差数列
X = np.linspace(a, b, n)
# 插值节点函数值
Y = 1/(1 + c * np.power(X, 2))

left_m = []
right_m = []
res = []

# 生成左右矩阵
for i in range(k+1):
    row = []
    for j in range(k+1):
        tmp = 0
        for h in range(n):
            tmp += np.power(X[h], i+j)
        row.append(tmp)
    left_m.append(row)
    tmpy = 0
    for g in range(n):
        tmpy += np.power(X[g], i) * Y[g]
    right_m.append(tmpy)

# 解方程组
res = list(reversed(np.linalg.solve(left_m, right_m)))

# 生成多项式函数
F = np.poly1d(res)

x = np.linspace(a, b, m)
y = []
for t in range(m):
    y.append(F(x[t]))
y_r = 1/(1 + c * np.power(x, 2))

y_e = y - y_r
y_error_a = np.mean(y_e)
print("average error: ", y_error_a)

# 画图
l1, = plt.plot(X, Y, label='theory')
l2, = plt.plot(x, y, label='least_square', linestyle='--')
plt.scatter(x, y)
plt.xlabel("x")
plt.ylabel("y")
plt.title('least_square')
plt.savefig("least_square.png")
plt.legend()   # 打上标签
plt.show()





