import operator

import numpy as np
import math

key = int(input("输入1用高斯赛德尔迭代法， 输入其他数将用SOR迭代法:  "))
if key == 1:
    w = 1.0
else:
    w = float(input("SOR迭代因子(不等于1):  "))
test = int(input("输入1用测试用例， 输入其他数将随机生成A，b，x_0:  "))
K = int(input("迭代最大步数(默认99):  "))

n = 0
if test == 1:
    n = 9
    # A为严格对角占优矩阵
    A = [[31.0, -13, 0, 0, 0, -10, 0, 0, 0],
         [-13, 35, -9, 0, -11, 0, 0, 0, 0],
         [0, -9, 31, -10, 0, 0, 0, 0, 0],
         [0, 0, -10, 79, -30, 0, 0, 0, -9],
         [0, 0, 0, -30, 57, -7, 0, -5, 0],
         [0, 0, 0, 0, -7, 47, -30, 0, 0],
         [0, 0, 0, 0, 0, -30, 41, 0, 0],
         [0, 0, 0, 0, -5, 0, 0, 27, -2],
         [0, 0, 0, -9, 0, 0, 0, -2, 29]]
    A = np.array(A)
    b = [-15.0, 27, -23, 0, -20, 12, -7, 7, 10]
    b = np.array(b)
    x_0 = np.zeros(9)
    S = 10e-8
else:
    n = int(input("输入n(>=20)的值，将随机生成n阶矩阵A和n维向量b: "))
    A = np.random.randint(-50, 50, (n, n))
    b = np.random.randint(-50, 50, n)
    x_0 = np.zeros(n)
    S = float(input("误差控制: "))

print("\n输出： ")
print("选取的A和b为： ")
print("A: \n", A)
print("b: ", b)

x_1 = np.zeros(n)
f = 0
# 最多迭代K次
for k in range(K):
    # 每次从x0 更新到 xn
    for i in range(n):
        tmp = x_0[i] + w*b[i]/A[i][i]
        for j in range(i):
            tmp -= (w/A[i][i])*(A[i][j]*x_1[j])
        for j_1 in range(i, n):
            tmp -= (w/A[i][i])*(A[i][j_1]*x_0[j_1])
        x_1[i] = tmp
    f += 1
    s = abs(max((x_1 - x_0), key=abs))
    if s < S:
        break
    else:
        for i in range(n):
            x_0[i] = x_1[i]
print("结果： ")
print("迭代步数： ", f)
if f >= 99:
    print("迭代在K步内不收敛！")
else:
    print("方程根值： ", x_1)

# 对于SOR的用例，求使迭代步数最小的w
if (key != 1) and (test == 1):
    f_t = []
    for p in range(1, 100):
        f_tmp = 0
        w_t = p/50.0
        x_0_t = np.zeros(n)
        x_1_t = np.zeros(n)
        for k in range(K):
            # 每次从x0 更新到 xn
            for i in range(n):
                tmp = x_0_t[i] + w_t * b[i] / A[i][i]
                for j in range(i):
                    tmp -= (w_t / A[i][i]) * (A[i][j] * x_1_t[j])
                for j_1 in range(i, n):
                    tmp -= (w_t / A[i][i]) * (A[i][j_1] * x_0_t[j_1])
                x_1_t[i] = tmp
            f_tmp += 1
            s_t = abs(max((x_1_t - x_0_t), key=abs))
            if s_t < S:
                break
            else:
                for i in range(n):
                    x_0_t[i] = x_1_t[i]
        f_t.append(f_tmp)
    min_index, min_number = min(enumerate(f_t), key=operator.itemgetter(1))
    print("对于SOR法：")
    print("w取" + str(min_index+1) + "/50时, 有最小迭代步数为：", min_number)
