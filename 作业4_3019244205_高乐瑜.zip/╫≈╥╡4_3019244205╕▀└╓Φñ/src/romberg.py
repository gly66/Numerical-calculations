from scipy import integrate
import numpy as np
import math

# 区间[a,b]
a = int(input("a: "))
b = int(input("b: "))
h = float(input("步长h的值: "))  # 步长
s = int(input("精度s的值: "))  # 精度


# 被积函数
def f(x):
    return math.sqrt(x) * math.log(x, math.e)


# 精确积分值
I_v = integrate.quad(f, a, b)[0]
# 划分次数
n = int((b-a)/h)
div_t = int(math.log(n, 2))

# 递推公式求T
T = []
T_0 = (b-a)/2 *(f(a) + f(b))
T.append(T_0)
for i in range(1, div_t+1):
    tmp = T[i-1]/2
    h_tmp = (b-a)/np.power(2, i-1)
    for j in range(np.power(2, i-1)):
        tmp += h_tmp/2 * f((a+j*h_tmp + a+(j+1)*h_tmp)/2)
    T.append(tmp)

A = np.zeros([div_t+1, div_t+1])
for i in range(div_t+1):
    A[i][0] = T[i]

# 外推
# i是列，j是行
for i in range(1, div_t+1):
    for j in range(i, div_t+1):
        a = np.power(4, i)/(np.power(4, i)-1)
        b = 1/(np.power(4, i)-1)
        A[j][i] = a * A[j][i-1] - b * A[j-1][i-1]

I_g = A[div_t][div_t]
I_e = abs(I_v - I_g)

print("积分准确结果： ", I_v)
print("龙贝格算法结果： ", I_g)
print("偏差： ", I_e)
print("划分次数： ", div_t)
print("步长： ", h)

