from scipy import integrate
import math

# 区间[a,b]
a = int(input("a: "))
b = int(input("b: "))
h = float(input("步长h的值: "))  # 步长
s = int(input("精度s的值: "))  # 精度


# 被积函数
def f(x):
    return math.sqrt(x) * math.log(x, math.e)


# 精确积分值
I_v = integrate.quad(f, a, b)[0]
# 划分次数

n = int((b-a)/h)
div_t = math.log(n, 2)

tmp = f(a) + f(b)

for k in range(1, n):
   tmp += 2*f(a + k*h)

# 梯形公式求得的积分值
T_n = tmp * h/2
# 偏差
I_e = abs(I_v-T_n)

print("积分准确结果： ", I_v)
print("梯形公式结果： ", T_n)
print("偏差： ", I_e)
print("划分次数： ", div_t)
print("步长： ", h)

